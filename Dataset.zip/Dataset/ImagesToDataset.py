####just copy and paste the below given code to your shell

# KERAS

import numpy as np
import os
import cv2
from sklearn.utils import shuffle
from sklearn.cross_validation import train_test_split

def get_data():
    # Definitions
    #TODO: Move definitons to seperate file
    path1 = 'C:/Users/hansk/CroppedImages/Combined'  # path of folder of images
    nb_class0 = 304
    nb_class1 = 333
    img_channels = 3

    listing = os.listdir(path1)
    num_samples=np.size(listing)

    imlist = os.listdir(path1)
    im1 = cv2.imread('C:/Users/hansk/CroppedImages/Combined/' + imlist[0], cv2.IMREAD_COLOR)
    img_rows = np.size(im1, 0)
    img_cols = np.size(im1, 1)  # get the size of the images

    # create matrix to store all flattened images
    immatrix = np.array([np.array(cv2.imread('C:/Users/hansk/CroppedImages/Combined/' + im2, cv2.IMREAD_COLOR)).flatten()
                      for im2 in imlist], 'f')
    label = np.ones((num_samples,), dtype=int)
    label[0:(nb_class0-1)] = 0
    label[nb_class0:(nb_class0+nb_class1-1)] = 1
    data, Label = shuffle(immatrix, label, random_state=2)
    train_data = [data, Label]

    # STEP 1: split X and y into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(train_data[0], train_data[1], test_size=0.2, random_state=4)

    # Return the sets to their original shapes
    X_train = X_train.reshape(X_train.shape[0], img_rows, img_cols, img_channels)
    X_test = X_test.reshape(X_test.shape[0], img_rows, img_cols, img_channels)

    # Scale the values from 0 to 1 instead of 0 to 255
    X_train = X_train.astype('float32')
    X_test = X_test.astype('float32')
    X_train /= 255
    X_test /= 255

    # convert class vectors to binary class matrices
    return (X_train, y_train), (X_test, y_test)
